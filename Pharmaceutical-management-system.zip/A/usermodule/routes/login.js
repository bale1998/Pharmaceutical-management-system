const express = require('express');
const router = express.Router();
const { Pool } = require('pg');
const Log = require('./login_data');
const { v4: uuidv4 } = require('uuid');
const cors = require('cors');

const pool = new Pool({
  user: 'postgres',
  host: 'localhost',
  database: 'usermodule',
  password: 'postgres',
  port: 5432,
});

router.use(cors()); // Enable CORS for all routes

router.post('/login', async (req, res, next) => {
  const { username, password } = req.body;
  try {
    // Validate the username and password
    const user = await validateUser(username, password, pool);

    if (!user) {
      // Invalid username or password
      res.status(401).json({ error: 'Invalid username or password' });
      return;
    }

    // Login successful
    // Log the action
    const logData = {
      log_id: Math.floor(Math.random() * (20102021 - 18202012 + 1)) + 18202012,
      log_datetime: new Date(),
      log_action: 'User Login',
      log_description: 'User logged in successfully',
      status: 'Success',
      user_id: user.user_id,
      partition_key: '1',
    };
    await Log.create(logData); // Log the user login

    // Return the role ID
    res.json({ role_id: user.role_id });
  } catch (error) {
    // Handle errors
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

async function validateUser(username, password, pool) {
  console.log(username + password);
  const query = 'SELECT user_id, role_id FROM user_ WHERE user_name = $1 AND password = $2';
  const values = [username, password];
  try {
    // Execute the database query
    const result = await pool.query(query, values);

    // Check if a matching user was found
    if (result.rows.length > 0) {
      // Return the user object with user_id and role_id
      const { user_id, role_id } = result.rows[0];
      return { user_id, role_id };
    } else {
      // User not found or invalid credentials
      return null;
    }
  } catch (error) {
    // Handle database errors
    console.error('Error validating user:', error);
    throw error;
  }
}
module.exports = router;
