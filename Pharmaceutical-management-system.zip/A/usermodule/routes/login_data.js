const { Pool } = require('pg');

const pool = new Pool({
  user: 'postgres',
  host: 'localhost',
  database: 'usermodule',
  password: 'postgres',
  port: 5432,
});

const Log = {
  async create(logData) {
    const client = await pool.connect();
    try {
      await client.query('BEGIN');
      const queryText = `
        INSERT INTO logs(log_id, log_datetime, log_action, log_description, status, user_id, partition_key)
        VALUES($1, $2, $3, $4, $5, $6, $7)
      `;
      const queryValues = [
        logData.log_id,
        logData.log_datetime,
        logData.log_action,
        logData.log_description,
        logData.status,
        logData.user_id,
        logData.partition_key
      ];
      await client.query(queryText, queryValues);
      await client.query('COMMIT');
    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally {
      client.release();
    }
  }
};
//module.exports = pool;
module.exports = Log;
