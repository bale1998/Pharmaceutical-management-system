const express = require('express');
const { getUserById, insertUserIntoTable, generateRandomUserId,deleteUserFromTable,updateUserRoleIdInTable, updateUserPasswordInTable} = require('./user_data');


const router = express.Router();

router.get('/get-user-details', async (req, res) => {
  const userId = 1; // ID of the user you want to retrieve

  try {
    const user = await getUserById(userId);
    res.json(user);
  } catch (error) {
    console.error('Error retrieving user:', error);
    res.status(500).send('Error retrieving user');
  }
});

router.post('/insert-user-details', async (req, res) => {
  const user = req.body; // User details received from the frontend

  try {
    const insertedUser = await insertUserIntoTable(user, 'user_');
    res.json(insertedUser);
  } catch (error) {
    console.error('Error inserting user:', error);
    if (error.message === 'User already available') {
      res.status(400).send('User already available');
    } else {
      res.status(500).send('Error inserting user');
    }
  }
});

router.delete('/delete-user/:userId', async (req, res) => {
  const userId = parseInt(req.params.userId, 10);

  try {
    const deletedUser = await deleteUserFromTable(userId, 'user_id');
    res.json(deletedUser);
  } catch (error) {
    console.error('Error deleting user:', error);
    res.status(500).send('Error deleting user');
  }
});

router.put('/update-user-role/:userId', async (req, res) => {
  const userId = parseInt(req.params.userId, 10);
  const { role_id } = req.body;

  try {
    const updatedUser = await updateUserRoleIdInTable(userId, role_id, 'user_id');
    res.json(updatedUser);
  } catch (error) {
    console.error('Error updating role_id:', error);
    res.status(500).send('Error updating role_id');
  }
});

router.put('/update-user-password/:userId', async (req, res) => {
  const userId = parseInt(req.params.userId, 10);
  const { password } = req.body;

  try {
    const updatedUser = await updateUserPasswordInTable(userId, password, 'user_id');
    res.json(updatedUser);
  } catch (error) {
    console.error('Error updating password:', error);
    res.status(500).send('Error updating password');
  }
});

module.exports = router;
