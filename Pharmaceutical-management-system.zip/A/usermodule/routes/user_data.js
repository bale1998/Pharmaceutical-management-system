const { Pool } = require('pg');

const pool = new Pool({
  user: 'postgres',
  host: 'localhost',
  database: 'usermodule',
  password: 'postgres',
  port: 5432,
});

const deleteUserFromTable = (userId) => {
  return new Promise((resolve, reject) => {
    pool.query(
      'DELETE FROM user_ WHERE user_id = $1 AND partition_key = 1',
      [parseInt(userId)],
      (error, result) => {
        if (error) {
          reject(error);
        } else {
          resolve();
        }
      }
    );
  });
};


const getUserById = (userId) => {
  return new Promise((resolve, reject) => {
    pool.query('SELECT user_id, login_id, email, password, user_name FROM user_ WHERE user_id = $1', [userId], (error, result) => {
      if (error) {
        reject(error);
      } else {
        resolve(result.rows[0]);
      }
    });
  });
};
// Function to generate a random user ID between 202100 and 202199
// Function to generate a random user ID between 202100 and 202199
function generateRandomUserId() {
  const min = 202100;
  const max = 202199;
  return Math.floor(Math.random() * (max - min + 1)) + min;
}



const insertUserIntoTable = (user, tableName) => {
  const { login_id, email, password, user_name, roleId } = user;
  const user_id = generateRandomUserId();
  const partition_key = '2'; // Replace with the actual partition key value

  return new Promise((resolve, reject) => {
    // Check if the login_id or email already exists
    pool.query(
      `SELECT * FROM ${tableName} WHERE login_id = $1 OR email = $2`,
      [login_id, email],
      (error, result) => {
        if (error) {
          reject(error);
        } else {
          // If the user already exists, return a message
          if (result.rows.length > 0) {
            resolve('User already available');
          } else {
            // Perform the insert operation
            pool.query(
              `INSERT INTO ${tableName} (user_id, login_id, email, password, user_name, role_id, partition_key) VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING *`,
              [user_id, login_id, email, password, user_name, roleId, partition_key],
              (error, result) => {
                if (error) {
                  reject(error);
                } else {
                  resolve(result.rows[0]);
                }
              }
            );
          }
        }
      }
    );
  });
};




const updateUserRoleIdInTable = (userId, roleId, idField) => {
  return new Promise((resolve, reject) => {
    const query = `UPDATE user_ SET role_id = $1 WHERE ${idField} = $2 RETURNING *`;
    const values = [roleId, userId];

    pool.query(query, values, (error, result) => {
      if (error) {
        reject(error);
      } else {
        resolve(result.rows[0]);
      }
    });
  });
};
const updateUserPasswordInTable = (userId, password, columnName) => {
  return new Promise((resolve, reject) => {
    const query = `UPDATE user_ SET password = $1 WHERE ${columnName} = $2 RETURNING *`;
    const values = [password, userId];

    pool.query(query, values, (error, result) => {
      if (error) {
        reject(error);
      } else {
        if (result.rows.length === 0) {
          resolve(null); // User not found, return null
        } else {
          resolve(result.rows[0]);
        }
      }
    });
  });
};



module.exports = { getUserById, insertUserIntoTable, generateRandomUserId,deleteUserFromTable, updateUserRoleIdInTable, updateUserPasswordInTable};
module.exports.generateRandomUserId = generateRandomUserId;
module.exports.deleteUserFromTable = deleteUserFromTable;
module.exports.updateUserPasswordInTable = updateUserPasswordInTable;
module.exports.insertUserIntoTable= insertUserIntoTable;
module.exports.getUserById = getUserById;
module.exports.updateUserRoleIdInTable = updateUserRoleIdInTable;
module.exports.pool = pool;


