const { Pool } = require('pg');

const pool = new Pool({
  user: 'postgres',
  host: 'localhost',
  database: 'pharmacymodule', 
  password: 'postgres',
  port: 5432,
});

const deleteOrderFromTable = (orderId) => {
  return new Promise((resolve, reject) => {
    pool.query(
      'DELETE FROM "order" WHERE order_id = $1',
      [parseInt(orderId)],
      (error, result) => {
        if (error) {
          reject(error);
        } else {
          resolve();
        }
      }
    );
  });
};

const getOrderById = (orderId) => {
  return new Promise((resolve, reject) => {
    pool.query(
      'SELECT order_id, quantity, Date_Ordered,staff, medication_id, pharmacy name  FROM "order" WHERE order_id = $1',
      [orderId],
      (error, result) => {
        if (error) {
          reject(error);
        } else {
          resolve(result.rows[0]);
        }
      }
    );
  });
};

// Function to generate a random order ID between 1000 and 1999
function generateRandomOrderId() {
  const min = 1000;
  const max = 1999;
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

const insertOrderIntoTable = (order, tableName) => {
  const { hospitalName, medicationList } = order;
  const orderId = generateRandomOrderId();
  let pharmacyId;

  if (hospitalName === 'Maseru Hospital') {
    pharmacyId = '1';
  } else if (hospitalName === 'Leribe Hospital') {
    pharmacyId = '1';
  } else if (hospitalName === 'Berea Hospital') {
    pharmacyId = '1';
  } else {
    // Handle the case when hospitalName doesn't match any conditions
    // You can set a default pharmacyId or handle the error accordingly
    return Promise.reject(new Error('Invalid hospitalName'));
  }

  const currentDate = new Date().toISOString(); // Get the current date in ISO format

  return new Promise((resolve, reject) => {
    const values = [];
    let valueIndex = 1;
    let query = `
      INSERT INTO ${tableName} (order_id, medication_id, quantity, pharmacy_id, date_ordered, partition_key)
      VALUES 
    `;
    
    for (const { medicationId, quantity } of medicationList) {
      query += `($${valueIndex++}, $${valueIndex++}, $${valueIndex++}, $${valueIndex++}, $${valueIndex++}, 1), `;
      values.push(orderId, medicationId, quantity, pharmacyId, currentDate);
    }

    query = query.slice(0, -2); // Remove the trailing comma and space
    query += ' RETURNING *';

    pool.query(query, values, (error, result) => {
      if (error) {
        reject(error);
      } else {
        resolve(result.rows);
      }
    });
  });
};



const updateOrderQuantityInTable = (orderId, quantity) => {
    return new Promise((resolve, reject) => {
      const query = 'UPDATE "order" SET quantity = $1 WHERE order_id = $2 RETURNING *';
      const values = [quantity, orderId];
  
      pool.query(query, values, (error, result) => {
        if (error) {
          reject(error);
        } else {
          resolve(result.rows[0]);
        }
      });
    });
};

module.exports = {getOrderById,insertOrderIntoTable,generateRandomOrderId,deleteOrderFromTable,updateOrderQuantityInTable,pool};
module.exports.generateRandomOrderId = generateRandomOrderId;
module.exports.deleteOrderFromTable = deleteOrderFromTable;
module.exports.updateOrderQuantityInTable = updateOrderQuantityInTable;
module.exports.insertOrderIntoTable = insertOrderIntoTable;
module.exports.getOrderById = getOrderById;
module.exports.pool = pool;