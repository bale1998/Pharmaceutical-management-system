const express = require('express');
const { generateRandomAllocationId,allocateMedicationToHospital, updateAllocationDeliveryStatus, getAllocationById } = require('./allocation_data');

const router = express.Router();

router.post('/allocate-medication', async (req, res) => {
  const allocation = req.body; // Allocation details received from the frontend

  try {
    const allocatedMedication = await allocateMedicationToHospital(allocation);
    res.json(allocatedMedication);
  } catch (error) {
    console.error('Error allocating medication:', error);
    res.status(500).send('Error allocating medication');
  }
});

router.put('/update-allocation-delivery-status/:allocationId', async (req, res) => {
  const allocationId = parseInt(req.params.allocationId, 10);
  const { delivered } = req.body;

  try {
    const updatedAllocation = await updateAllocationDeliveryStatus(allocationId, delivered);
    res.json(updatedAllocation);
  } catch (error) {
    console.error('Error updating delivery status:', error);
    res.status(500).send('Error updating delivery status');
  }
});

router.get('/get-allocation-details/:allocationId', async (req, res) => {
  const allocationId = parseInt(req.params.allocationId, 10);

  try {
    const allocation = await getAllocationById(allocationId);
    res.json(allocation);
  } catch (error) {
    console.error('Error retrieving allocation:', error);
    res.status(500).send('Error retrieving allocation');
  }
});

module.exports = router;
