const { Pool } = require('pg');

const pool = new Pool({
  user: 'postgres',
  host: '197.220.152.87',
  database: 'pharmacymodule',
  password: 'postgres',
  port: 5432,
});

function generateRandomAllocationId() {
    const min = 200;
    const max = 299;
    return Math.floor(Math.random() * (max - min + 1)) + min;
  }

const allocateMedicationToHospital = (allocation, tableName) => {
  const {medication_id, quantity, delivered, hospital_name} = allocation;
  const allocation_id = generateRandomAllocationId();
  const partition_key = '1'; // Replace with the actual partition key value


  return new Promise((resolve, reject) => {
     // Check if the allocation_id already exists
     pool.query(
        `SELECT * FROM allocation WHERE allocation_id = $1`,
        [allocation_id],
        (error, result) => {
          if (error) {
            reject(error);
          } else {
            // If the allocation already exists, return a message
            if (result.rows.length > 0) {
              resolve('Allocation can not be repeated');
            } else {
    // Perform the insert operation
    pool.query(
      'INSERT INTO allocation (partition_key,allocation_id, medication_id, quantity, delivered, hospital_name) VALUES ($1, $2, $3, $4,$5, $6) RETURNING *',
      [partition_key, allocation_id, medication_id, quantity, delivered,hospital_name],
      (error, result) => {
        if (error) {
          reject(error);
        } else {
          resolve(result.rows[0]);
        }
       });
      }
     }
    });
  });
};

const updateAllocationDeliveryStatus = (allocationId, delivered) => {
  return new Promise((resolve, reject) => {
    pool.query(
      'UPDATE allocation SET delivered = $1 WHERE allocation_id = $2 RETURNING *',
      [delivered, allocationId],
      (error, result) => {
        if (error) {
          reject(error);
        } else {
          resolve(result.rows[0]);
        }
      }
    );
  });
};

const getAllocationById = (allocationId) => {
  return new Promise((resolve, reject) => {
    pool.query('SELECT * FROM allocation WHERE allocation_id = $1', [allocationId], (error, result) => {
      if (error) {
        reject(error);
      } else {
        resolve(result.rows[0]);
      }
    });
  });
};

module.exports = {generateRandomAllocationId,allocateMedicationToHospital, updateAllocationDeliveryStatus, getAllocationById};
module.exports.generateRandomAllocationId = generateRandomAllocationId;
module.exports.allocateMedicationToHospital =allocateMedicationToHospital;
module.exports.updateAllocationDeliveryStatus = updateAllocationDeliveryStatus;
module.exports.getAllocationById= getAllocationById;
module.exports.pool = pool;