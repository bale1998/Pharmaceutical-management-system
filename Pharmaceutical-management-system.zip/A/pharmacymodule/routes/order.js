const express = require('express');
const { getOrderById, insertOrderIntoTable, generateRandomOrderId, deleteOrderFromTable, updateOrderQuantityInTable } = require('./order_data');

const router = express.Router();

router.get('/get-order-details', async (req, res) => {
  const orderId = 1; // ID of the order you want to retrieve

  try {
    const order = await getOrderById(orderId);
    res.json(order);
  } catch (error) {
    console.error('Error retrieving order:', error);
    res.status(500).send('Error retrieving order');
  }
});

router.post('/insert-order-details', async (req, res) => {
  const order = req.body; // Order details received from the frontend

  try {
    const insertedOrder = await insertOrderIntoTable(order, 'orders');
    res.json(insertedOrder);
  } catch (error) {
    console.error('Error inserting order:', error);
    if (error.message === 'Order already available') {
      res.status(400).send('Order already available');
    } else {
      res.status(500).send('Error inserting order');
    }
  }
});router.delete('/delete-order/:orderId', async (req, res) => {
  const orderId = parseInt(req.params.orderId, 10);

  try {
    const deletedOrder = await deleteOrderFromTable(orderId, 'order_id');
    res.json(deletedOrder);
  } catch (error) {
    console.error('Error deleting order:', error);
    res.status(500).send('Error deleting order');
  }
});

router.put('/update-order-quantity/:orderId', async (req, res) => {
  const orderId = parseInt(req.params.orderId, 10);
  const { quantity } = req.body;

  try {
    const updatedOrder = await updateOrderQuantityInTable(orderId, quantity, 'order_id');
    res.json(updatedOrder);
  } catch (error) {
    console.error('Error updating quantity:', error);
    res.status(500).send('Error updating quantity');
  }
});

module.exports = router;
