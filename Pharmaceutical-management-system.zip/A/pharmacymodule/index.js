const cors = require('cors');
const express = require('express');
const allocationRouter = require('./routes/allocation');
const orderRouter = require('./routes/order');
const app = express();

app.use(cors());
app.use(express.json());

app.use('/allocation', allocationRouter);
app.use('/order', orderRouter);
const PORT = 3006;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
