import React, { useState, useEffect } from 'react';
import Axios from 'axios';

const App = () => {
  const [user, setUser] = useState(null);
  const [errorMessage, setErrorMessage] = useState(null);

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const response = await Axios.get('http://localhost:3003/users/get-user-details');
        setUser(response.data);
      } catch (error) {
        console.error('Error retrieving user:', error);
      }
    };

    fetchUser();
  }, []);


  document.getElementById('delete-button').addEventListener('click', async () => {
    const userId = document.getElementById('user-id-input').value;
  
    try {
      const response = await fetch(`http://localhost:3003/users/delete-user/${userId}`, {
        method: 'DELETE',
        headers: {
          'Content-Type': 'application/json'
        }
      });
  
      if (response.ok) {
        console.log('User deleted successfully');
        // Perform any additional actions after successful deletion
      } else {
        console.error('Error:', response.status);
        // Handle error response
      }
    } catch (error) {
      console.error('Error:', error);
    }
  });
  
  const deleteUser = async (userId) => {
    try {
      const response = await fetch(`http://localhost:3003/users/delete-user/${userId}`, {
        method: 'DELETE',
        headers: {
          'Content-Type': 'application/json'
        }
      });
  
      if (response.ok) {
        console.log('User deleted successfully');
        // Perform any additional actions after successful deletion
      } else {
        console.error('Error:', response.status);
        // Handle error response
      }
    } catch (error) {
      console.error('Error:', error);
    }
  };
  
  
  const deleteButton = document.getElementById('delete-button');
  const userIdInput = document.getElementById('user-id-input');
  
  deleteButton.addEventListener('click', () => {
    const userIdToDelete = userIdInput.value;
    deleteUser(userIdToDelete);
  });
  

  const handleInsertUser = async () => {
    const newUser = {
      login_id: 'CLoahna123',
      email: 'AjohhAac@example.com',
      password: 'mypassword',
      user_name: 'John Doe'
    };

    try {
      const response = await Axios.post('http://localhost:3003/users/insert-user-details', newUser);
      const responseData = response.data;

      if (responseData.message) {
        console.log('Error inserting user:', responseData.message);
        setErrorMessage(responseData.message); // Set the error message in the state
      } else {
        console.log('User inserted:', responseData);
        // Handle successful user insertion
      }
    } catch (error) {
      console.error('Error inserting user:', error);
      setErrorMessage('Error inserting user'); // Set a generic error message in the state
    }
  };

  return (
    <div>
      {user ? (
        <div>
          <h2>User Details</h2>
          <p>User ID: {user.user_id}</p>
          <p>Login ID: {user.login_id}</p>
          <p>Email: {user.email}</p>
          <p>Password: {user.password}</p>
          <p>User Name: {user.user_name}</p>
        </div>
      ) : (
        <p>Loading user data...</p>
      )}

      {errorMessage && <p>Error: {errorMessage}</p>} {/* Display the error message if present */}

      <button onClick={handleInsertUser}>Insert User</button>
    </div>
  );
};


// Update user role
const updateUserRole = async (userId, roleId) => {
  const url = `http://localhost:3003/users/update-user-role/${userId}`;
  const data = {
    role_id: roleId
  };

  try {
    const response = await fetch(url, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(data)
    });

    if (response.ok) {
      const updatedUser = await response.json();
      console.log('User role updated:', updatedUser);
      // Perform any necessary actions with the updated user data
    } else {
      console.error('Error updating user role:', response.status);
      // Handle the error appropriately
    }
  } catch (error) {
    console.error('Error updating user role:', error);
    // Handle the error appropriately
  }
};

// Button click event handler
const updateButton = document.getElementById('updateButton');
updateButton.addEventListener('click', () => {
  const userIdInput = document.getElementById('userIdInput');
  const roleIdInput = document.getElementById('roleIdInput');
  
  const userId = parseInt(userIdInput.value, 10);
  const roleId = parseInt(roleIdInput.value, 10);
  
  updateUserRole(userId, roleId);
});



// HTML elements
const userIdInput = document.getElementById('userIdInput');
const passwordInput = document.getElementById('passwordInput');
const updatePasswordButton = document.getElementById('updatePasswordButton');

// Update user password
const updateUserPassword = async (userId, password) => {
  const url = `http://localhost:3003/users/update-user-password/${userId}`;
  const data = {
    password: password
  };

  try {
    const response = await fetch(url, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(data)
    });

    if (response.ok) {
      const updatedUser = await response.json();
      console.log('User password updated:', updatedUser);
      // Perform any necessary actions with the updated user data
    } else {
      console.error('Error updating user password:', response.status);
      // Handle the error appropriately
    }
  } catch (error) {
    console.error('Error updating user password:', error);
    // Handle the error appropriately
  }
};

// Button click event handler
updatePasswordButton.addEventListener('click', () => {
  const userId = parseInt(userIdInput.value, 10);
  const password = passwordInput.value;

  if (isNaN(userId)) {
    console.error('Invalid user ID');
    return;
  }
  
  updateUserPassword(userId, password);
});


const OrderForm = () => {
  const [unitId, setUnitId] = useState('');
  const [orders, setOrders] = useState([]);
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const response = await fetch(`http://localhost:3003/medication/get-orders-by-unit?unitId=${unitId}`);
      if (!response.ok) {
        throw new Error('Error retrieving orders');
      }

      const data = await response.json();
      setOrders(data);
      setError('');
    } catch (error) {
      console.error('Error retrieving orders:', error);
      setError('Error retrieving orders');
      setOrders([]);
    }
  };

  const handleChangeQuantity = (e, index) => {
    const newOrders = [...orders];
    newOrders[index].quantity = e.target.value;
    setOrders(newOrders);
  };

  const handleSave = () => {
    // Perform the necessary logic to save the updated orders
    console.log(orders);
  };

  return (
    <div>
      <h2>Order Form</h2>
      <form onSubmit={handleSubmit}>
        <label htmlFor="unitId">Unit ID:</label>
        <input
          type="text"
          id="unitId"
          value={unitId}
          onChange={(e) => setUnitId(e.target.value)}
        />

        <button type="submit">Retrieve Orders</button>
      </form>

      {error && <p>{error}</p>}

      {orders.length > 0 && (
        <div>
          <h3>Orders</h3>
          <table>
            <thead>
              <tr>
                <th>Medication ID</th>
                <th>Quantity</th>
              </tr>
            </thead>
            <tbody>
              {orders.map((order, index) => (
                <tr key={index}>
                  <td>{order.medicationId}</td>
                  <td>
                    <input
                      type="number"
                      value={order.quantity}
                      onChange={(e) => handleChangeQuantity(e, index)}
                    />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          <button onClick={handleSave}>Submit</button>
        </div>
      )}
    </div>
  );
};
export default App;
