const cors = require('cors');
const express = require('express');
const medicationRouter = require('./routes/medication');
const administrationRouter = require('./routes/administration');
const allocationsRouter = require('./routes/allocations');
const app = express();

app.use(cors());
app.use(express.json());

app.use('/medication', medicationRouter);
app.use('/administration', administrationRouter);
app.use('/allocations',allocationsRouter);
const PORT = 3004;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
