const { Pool } = require('pg');

const pool = new Pool({
  user: 'postgres',
  host: 'localhost',
  database: 'medicationmodule',
  password: 'postgres',
  port: 5432,
});

function generateRandomallocationId() {
    const min = 400;
    const max = 499;
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

const allocateMedicationToUnit = (allocation) => {
  const { medication_id, quantity, unit_id } = allocation;
  const allocation_id = generateRandomallocationId();
  const partition_key = '1'; // Replace with the actual partition key value


  return new Promise((resolve, reject) => {
    pool.query(
      'INSERT INTO allocations (allocation_id, partition_key, medication_id, quantity, unit_id) VALUES ($1, $2, $3,$4, $5) RETURNING *',
      [allocation_id, partition_key, medication_id, quantity, unit_id],
      (error, result) => {
        if (error) {
          reject(error);
        } else {
          resolve(result.rows[0]);
        }
      }
    );
  });
};

const updateAllocationStatus = (allocationId, delivered) => {
  return new Promise((resolve, reject) => {
    pool.query(
      'UPDATE allocations SET delivered = $1 WHERE allocation_id = $2 RETURNING *',
      [delivered, allocationId],
      (error, result) => {
        if (error) {
          reject(error);
        } else {
          resolve(result.rows[0]);
        }
      }
    );
  });
};

const getAllocationById = (allocationId) => {
  return new Promise((resolve, reject) => {
    pool.query(
      'SELECT * FROM allocations WHERE allocation_id = $1',
      [allocationId],
      (error, result) => {
        if (error) {
          reject(error);
        } else {
          resolve(result.rows[0]);
        }
      }
    );
  });
};

module.exports = { allocateMedicationToUnit, updateAllocationStatus, getAllocationById,generateRandomallocationId, pool,};
module.exports.allocateMedicationToUnit = allocateMedicationToUnit;
module.exports.updateAllocationStatus = updateAllocationStatus;
module.exports.getAllocationById = getAllocationById;
module.exports.generateRandomallocationId = generateRandomallocationId;
module.exports.pool = pool;
