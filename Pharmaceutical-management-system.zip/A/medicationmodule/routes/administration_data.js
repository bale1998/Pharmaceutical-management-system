const { Pool } = require('pg');

const pool = new Pool({
  user: 'postgres',
  host: 'localhost',
  database: 'medicationmodule',
  password: 'postgres',
  port: 5432,
});

const deleteAdministrationFromTable = (administrationId) => {
  return new Promise((resolve, reject) => {
    pool.query(
      'DELETE FROM administration WHERE administration_id = $1',
      [parseInt(administrationId)],
      (error, result) => {
        if (error) {
          reject(error);
        } else {
          resolve();
        }
      }
    );
  });
};

const getAdministrationByPatientName = (patient_name) => {
  return new Promise((resolve, reject) => {
    pool.query(
      'SELECT * FROM med_administration WHERE patient_name = $1',
      [patient_name],
      (error, result) => {
        if (error) {
          reject(error);
        } else {
          resolve(result.rows[0]);
        }
      }
    );
  });
};

// Function to generate a random Administration ID between 102100 and 102199
// Function to generate a random Administration ID between 102100 and 102199
function generateRandomAdministrationId() {
    const min = 102100;
    const max = 102199;
    return Math.floor(Math.random() * (max - min + 1)) + min;
  }
  
const insertAdministrationIntoTable = (Administration) => {
  const { ward_number, patient_name, medication_id, date, professional_name } = Administration;
  const administration_id = generateRandomAdministrationId();
  const partition_key = '1'; // Replace with the actual partition key value

  return new Promise((resolve, reject) => {
    // Check if the administration_id already exists
    pool.query(
      `SELECT * FROM ${tableName} WHERE administration_id = $1`,
      [login_id],
      (error, result) => {
        if (error) {
          reject(error);
        } else {
          // If the administration already exists, return a message
          if (result.rows.length > 0) {
            resolve('Administration can not be repeated');
          } else {
              // Perform the insert operation
            pool.query(
                'INSERT INTO administration (administration_id, ward_number, patient_name, medication_id, date, professional_name, partition_key) VALUES ($1, $2, $3, $4, $5, $6) RETURNING *',
                [administration_id, ward_number, patient_name, medication_id, date, professional_name, partition_key],
                (error, result) => {
                if (error) {
                     reject(error);
                 } else {
                     resolve(result.rows[0]);
                       }
                    }
                );
            }
        }
      }
    );
 });
};

const updateAdministrationDetails = (administrationId, updatedData) => {
  return new Promise((resolve, reject) => {
    const { ward_number, patient_name, medication_id, date, professional_name } = updatedData;
    const query =
      'UPDATE administration SET ward_number = $1, patient_name = $2, medication_id = $3, date = $4, professional_name = $5 WHERE administration_id = $6 RETURNING *';
    const values = [ward_number, patient_name, medication_id, date, professional_name, administrationId];

    pool.query(query, values, (error, result) => {
      if (error) {
        reject(error);
      } else {
        resolve(result.rows[0]);
      }
    });
  });
};

module.exports = {deleteAdministrationFromTable,getAdministrationByPatientName,insertAdministrationIntoTable,generateRandomAdministrationId,pool,};
module.exports. deleteAdministrationFromTable  = deleteAdministrationFromTable; 
module.exports. getAdministrationByPatientName  = getAdministrationByPatientName; 
module.exports. insertAdministrationIntoTable  = insertAdministrationIntoTable; 
module.exports. updateAdministrationDetails  = updateAdministrationDetails;
module.exports. generateRandomAdministrationId  = generateRandomAdministrationId ;
module.exports. pool  = pool; 