const express = require('express');
const {deleteAdministrationFromTable,getAdministrationByPatientName,insertAdministrationIntoTable,updateAdministrationDetails,generateRandomAdministrationId} = require('./administration_data');

const router = express.Router();

router.get('/get-administration-details', async (req, res) => {
  const patient_name = req.query.patient_name;

  try {
    const administration = await getAdministrationByPatientName(patient_name);
    res.json(administration);
  } catch (error) {
    console.error('Error retrieving medication administration:', error);
    res.status(500).send('Error retrieving medication administration');
  }
});

router.post('/insert-administration-details', async (req, res) => {
  const administration = req.body; // Medication administration details received from the frontend

  try {
    const insertedAdministration = await insertAdministrationIntoTable(administration,'administration_');
    res.json(insertedAdministration);
  } catch (error) {
    console.error('Error inserting medication administration:', error);
    res.status(500).send('Error inserting medication administration');
  }
});

router.delete('/delete-administration/:administrationId', async (req, res) => {
  const administrationId = parseInt(req.params.administrationId, 10);

  try {
    const deletedAdministration = await deleteAdministrationFromTable(administrationId, 'administration_id');
    res.json(deletedAdministration);
  } catch (error) {
    console.error('Error deleting medication administration:', error);
    res.status(500).send('Error deleting medication administration');
  }
});

router.put('/update-administration-details/:administrationId', async (req, res) => {
  const administrationId = parseInt(req.params.administrationId, 10);
  const updatedData = req.body; // Updated medication administration details

  try {
    const updatedAdministrationDetails = await updateAdministrationDetails(administrationId, updatedData, 'administration_id');
    res.json(updatedAdministration);
  } catch (error) {
    console.error('Error updating medication administration:', error);
    res.status(500).send('Error updating medication administration');
  }
});

module.exports = router;
