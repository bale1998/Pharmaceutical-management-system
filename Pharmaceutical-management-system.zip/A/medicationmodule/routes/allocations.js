const express = require('express');
const { allocateMedicationToUnit, updateAllocationStatus, getAllocationById,generateRandomallocationId,} = require('./allocations_data');

const router = express.Router();

router.post('/allocate-medication', async (req, res) => {
  const allocation = req.body; // Allocation details received from the frontend

  try {
    const allocatedMedication = await allocateMedicationToUnit(allocation);
    res.json(allocatedMedication);
  } catch (error) {
    console.error('Error allocating medication:', error);
    res.status(500).send('Error allocating medication');
  }
});

router.put('/update-allocation-delivery-status/:allocationId', async (req, res) => {
  const allocationId = parseInt(req.params.allocationId, 10);
  const { delivered } = req.body;

  try {
    const updatedAllocation = await updateAllocationStatus(allocationId, delivered);
    res.json(updatedAllocation);
  } catch (error) {
    console.error('Error updating allocation delivery status:', error);
    res.status(500).send('Error updating allocation delivery status');
  }
});

router.get('/get-allocation/:allocationId', async (req, res) => {
  const allocationId = parseInt(req.params.allocationId, 10);

  try {
    const allocation = await getAllocationById(allocationId);
    res.json(allocation);
  } catch (error) {
    console.error('Error retrieving allocation:', error);
    res.status(500).send('Error retrieving allocation');
  }
});

module.exports = router;
