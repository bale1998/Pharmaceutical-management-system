const express = require('express');
const { getMedicationById, getOrdersByUnitId, insertOrder, insertMedicationIntoTable, deleteMedicationFromTable, updateMedicationQuantityInTable, updateMedicationExpiryDateInTable, generateRandomUMedicationId } = require('./medication_data');
const Log = require('./log'); // Assuming you have a Log model or module to handle logging

const router = express.Router();

const logAction = async (logAction, logDescription, status, userId) => {
  const logData = {
    log_id: Math.floor(Math.random() * (20102021 - 18202012 + 1)) + 18202012,
    log_datetime: new Date(),
    log_action: logAction,
    log_description: logDescription,
    status,
    user_id: userId,
    partition_key: '1',
  };
  
  await Log.create(logData); // Log the action
};

router.get('/get-orders-by-unit', async (req, res) => {
  const unitId = req.query.unitId; // Assuming unitId is provided as a query parameter

  try {
    const orders = await getOrdersByUnitId(unitId);
    res.json(orders);
  } catch (error) {
    console.error('Error retrieving orders:', error);
    await logAction('Get Orders', 'Error retrieving orders', 'Error', req.user_id);
    res.status(500).send('Error retrieving orders');
  }
});

router.post('/insert-order', async (req, res) => {
  const { quantity, medicationId, wardId } = req.body;
  const unitId = wardId; // Map wardId to unitId
  const dateOrdered = new Date().toISOString(); // Current system time

  try {
    await insertOrder(quantity, medicationId, unitId, dateOrdered);
    await logAction('Insert Order', 'Order inserted successfully', 'Success', req.user_id);
    res.json({ message: 'Order inserted successfully' }); // Send JSON response
  } catch (error) {
    console.error('Error inserting order:', error);
    await logAction('Insert Order', 'Error inserting order', 'Error', req.user_id);
    res.status(500).json({ error: 'Error inserting order' }); // Send JSON response with error message
  }
});

router.get('/get-medication-details', async (req, res) => {
  const medicationId = 1; // ID of the medication you want to retrieve

  try {
    const medication = await getMedicationById(medicationId);
    res.json(medication);
  } catch (error) {
    console.error('Error retrieving medication:', error);
    await logAction('Get Medication', 'Error retrieving medication', 'Error', req.user_id);
    res.status(500).send('Error retrieving medication');
  }
});

router.post('/insert-medication-details', async (req, res) => {
  const medication = req.body; // Medication details received from the frontend

  try {
    const insertedMedication = await insertMedicationIntoTable(medication, 'medication_');
    await logAction('Insert Medication', 'Medication inserted successfully', 'Success', req.user_id);
    res.json(insertedMedication);
  } catch (error) {
    console.error('Error inserting medication:', error);
    if (error.message === 'Medication already available') {
      await logAction('Insert Medication', 'Medication already available', 'Error', req.user_id);
      res.status(400).send('Medication already available');
    } else {
      await logAction('Insert Medication', 'Error inserting medication', 'Error', req.user_id);
      res.status(500).send('Error inserting medication');
    }
  }
});

router.delete('/delete-medication/:medicationId', async (req, res) => {
  const medicationId = parseInt(req.params.medicationId, 10);

  try {
    const deletedMedication = await deleteMedicationFromTable(medicationId, 'medication_id');
    await logAction('Delete Medication', 'Medication deleted successfully', 'Success', req.user_id);
    res.json(deletedMedication);
  } catch (error) {
    console.error('Error deleting medication:', error);
    await logAction('Delete Medication', 'Error deleting medication', 'Error', req.user_id);
    res.status(500).send('Error deleting medication');
  }
});

router.put('/update-medication-quantity/:medicationId', async (req, res) => {
  const medicationId = parseInt(req.params.medicationId, 10);
  const { quantity } = req.body;

  try {
    const updatedMedication = await updateMedicationQuantityInTable(medicationId, quantity, 'medication_id');
    await logAction('Update Medication Quantity', 'Medication quantity updated successfully', 'Success', req.user_id);
    res.json(updatedMedication);
  } catch (error) {
    console.error('Error updating quantity:', error);
    await logAction('Update Medication Quantity', 'Error updating quantity', 'Error', req.user_id);
    res.status(500).send('Error updating quantity');
  }
});

router.put('/update-medication-expiry-date/:medicationId', async (req, res) => {
  const medicationId = parseInt(req.params.medicationId, 10);
  const { expiryDate } = req.body;

  try {
    const updatedMedication = await updateMedicationExpiryDateInTable(medicationId, expiryDate, 'medication_id');
    await logAction('Update Medication Expiry Date', 'Medication expiry date updated successfully', 'Success', req.user_id);
    res.json(updatedMedication);
  } catch (error) {
    console.error('Error updating expiry date:', error);
    await logAction('Update Medication Expiry Date', 'Error updating expiry date', 'Error', req.user_id);
    res.status(500).send('Error updating expiry date');
  }
});

module.exports = router;
