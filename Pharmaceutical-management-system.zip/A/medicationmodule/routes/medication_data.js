const { Pool } = require('pg');

const pool = new Pool({
  user: 'postgres',
  host: 'localhost',
  database: 'medicationmodule',
  password: 'postgres',
  port: 5432,
});

const getOrdersByUnitId = (unitId) => {
    return new Promise((resolve, reject) => {
      pool.query('SELECT COUNT(*) FROM medication_orders WHERE unit_id = $1', [unitId], (error, result) => {
        if (error) {
          reject(error);
        } else {
          const rowCount = parseInt(result.rows[0].count);
          if (rowCount === 0) {
            // If the unit_id does not exist, reject the promise with an error message
            reject(new Error('Unit ID does not exist.'));
          } else {
            // Unit ID exists, proceed to retrieve the orders
            pool.query('SELECT quantity, medication_id FROM medication_orders WHERE unit_id = $1', [unitId], (error, result) => {
              if (error) {
                reject(error);
              } else {
                const records = result.rows.map(row => ({
                  quantity: row.quantity,
                  medicationId: row.medication_id,
                }));
                resolve(records);
              }
            });
          }
        }
      });
    });
  };


  const insertOrder = (quantity, medicationId, unitId, dateOrdered) => {
    const min = 503021;
    const max = 709031;
    const orderId = Math.floor(Math.random() * (max - min + 1)) + min; // Generate a random orderId within the range
  
    return new Promise((resolve, reject) => {
      pool.query(
        'INSERT INTO medication_orders (partition_key, order_id, date_ordered, quantity, medication_id, unit_id) VALUES ($1, $2, $3, $4, $5, $6)',
        [1, orderId, dateOrdered, quantity, medicationId, unitId],
        (error, result) => {
          if (error) {
            reject(error);
          } else {
            resolve(result);
          }
        }
      );
    });
  };


  const insertMedicationIntoTable = (medicationData) => {
    const { medicationId, name, quantity, dosage, routeOfAdministration, frequency } = medicationData;
    const partitionKey = 1; // Assuming partition_key is always 1
    //const dateInserted = new Date().toISOString(); // Current system time
  
    return new Promise((resolve, reject) => {
      pool.query(
        'INSERT INTO medication (partition_key, medication_id, name, quantity, dosage, routeofadministration, frequency) VALUES ($1, $2, $3, $4, $5, $6, $7)',
        [partitionKey, medicationId, name, quantity, dosage, routeOfAdministration, frequency],
        (error, result) => {
          if (error) {
            reject(error);
          } else {
            resolve(result);
          }
        }
      );
    });
  };
  
const deleteMedicationFromTable = (medicationId) => {
  return new Promise((resolve, reject) => {
    pool.query(
      'DELETE FROM medication WHERE medication_id = $1',
      [parseInt(medicationId)],
      (error, result) => {
        if (error) {
          reject(error);
        } else {
          resolve();
        }
      }
    );
  });
};

const getMedicationById = (medicationId) => {
  return new Promise((resolve, reject) => {
    pool.query('SELECT medication_id, quantity_available, quantity_delivered, expiry_date FROM medication WHERE medication_id = $1', [medicationId], (error, result) => {
      if (error) {
        reject(error);
      } else {
        resolve(result.rows[0]);
      }
    });
  });
};

function generateRandomMedicationId() {
    const min = 200100;
    const max = 200199;
    return Math.floor(Math.random() * (max - min + 1)) + min;
  }


const updateMedicationQuantityInTable = (medicationId, quantityAvailable, quantityDelivered, idField) => {
  return new Promise((resolve, reject) => {
    const query = `UPDATE medication SET quantity_available = $1, quantity_delivered = $2 WHERE ${idField} = $3 RETURNING *`;
    const values = [quantityAvailable, quantityDelivered, medicationId];

    pool.query(query, values, (error, result) => {
      if (error) {
        reject(error);
      } else {
        resolve(result.rows[0]);
      }
    });
  });
};

const updateMedicationExpiryDateInTable = (medicationId, expiryDate, idField) => {
  return new Promise((resolve, reject) => {
    const query = `UPDATE medication SET expiry_date = $1 WHERE ${idField} = $2 RETURNING *`;
    const values = [expiryDate, medicationId];

    pool.query(query, values, (error, result) => {
      if (error) {
        reject(error);
      } else {
        resolve(result.rows[0]);
      }
    });
  });
};

module.exports = {getMedicationById,insertMedicationIntoTable,insertOrder,getOrdersByUnitId,deleteMedicationFromTable,updateMedicationQuantityInTable,updateMedicationExpiryDateInTable};
module.exports.generateRandomMedicationId = generateRandomMedicationId;
module.exports.getOrdersByUnitId = getOrdersByUnitId;
module.exports.insertOrder = insertOrder;
module.exports.deleteMedicationFromTable = deleteMedicationFromTable;
module.exports.updateMedicationExpiryDateInTable = updateMedicationExpiryDateInTable;
module.exports.insertMedicationIntoTable= insertMedicationIntoTable;
module.exports.getMedicationById = getMedicationById;
module.exports.updateMedicationQuantityInTable = updateMedicationQuantityInTable;
module.exports.pool = pool;